package task_03;

public class Felime extends Mammal{


    public Felime(String animalName, String animalType, Double animalWeight, String livingRegion, Integer foodEaten) {
        super(animalName, animalType, animalWeight, livingRegion, foodEaten);
    }

    @Override
    public void makeSound() {

    }

    @Override
    public void eat(Food food) {

    }

    @Override
    public void foodCheck(String foodType) {

    }

}
