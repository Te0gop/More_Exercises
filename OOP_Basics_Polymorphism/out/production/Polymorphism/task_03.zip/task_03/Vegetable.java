package task_03;

public class Vegetable extends Food{
    public Vegetable(Integer quantity) {
        super(quantity);
    }
}
